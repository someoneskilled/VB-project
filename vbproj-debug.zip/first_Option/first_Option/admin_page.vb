﻿Public Class admin_page
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        admin_add_edit_voters.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        admin_add_edit_cand.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        elections.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        generate_reports.Show()
    End Sub

    Private Sub admin_page_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class