﻿Imports MySql.Data.MySqlClient

Public Class finish_election

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim electionId As Integer = Integer.Parse(TextBox1.Text)

        Dim connStr As String = "server=localhost;user=root;password=helloworld;database=project"


        Try
            Using conn As New MySqlConnection(connStr)
                conn.Open()

                Dim sql As String = "update Elections set is_active = 0 where election_id = @electionId"
                Using cmd As New MySqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@electionId", electionId)

                    Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                    If rowsAffected > 0 Then
                        MessageBox.Show("Election updated successfully.")
                    Else
                        MessageBox.Show("No rows affected. Election update failed.")
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error updating election: " & ex.Message)
        End Try
    End Sub

    Private Sub finish_election_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
