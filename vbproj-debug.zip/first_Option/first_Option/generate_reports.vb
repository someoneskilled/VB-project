﻿Imports MySql.Data.MySqlClient
Public Class generate_reports
    Private Sub generate_reports_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim electionIdInput As String = InputBox("Enter Election ID:", "Election ID Input")

        If Not String.IsNullOrEmpty(electionIdInput) Then
            Dim electionId As Integer
            If Integer.TryParse(electionIdInput, electionId) Then
                Try
                    Dim connStr As String = "server=localhost;user=root;password=helloworld;database=project"

                    Using conn As New MySqlConnection(connStr)
                        conn.Open()

                        ' Check if the election is not active
                        Dim electionStatusQuery As String = "select is_active from elections where election_id = @electionId"
                        Using cmdStatus As New MySqlCommand(electionStatusQuery, conn)
                            cmdStatus.Parameters.AddWithValue("@electionId", electionId)
                            Dim isActive As Boolean = Convert.ToBoolean(cmdStatus.ExecuteScalar())

                            If isActive Then
                                MessageBox.Show("Cannot generate reports for an ongoing election.")
                                Me.Close()
                                Return
                            End If
                        End Using

                        Dim allvotes As Integer
                        Dim totalVotesQuery As String = "select count(*) AS total_votes from votes where election_id = @electionId"
                        Using cmdTotalVotes As New MySqlCommand(totalVotesQuery, conn)
                            cmdTotalVotes.Parameters.AddWithValue("@electionId", electionId)
                            allvotes = Convert.ToInt32(cmdTotalVotes.ExecuteScalar())
                            Label8.Text = "Total Votes: " & allvotes
                        End Using

                        ' Fetch election details
                        Dim electionQuery As String = "select title, start_date, end_date from elections where election_id = @electionId"
                        Using cmdElection As New MySqlCommand(electionQuery, conn)
                            cmdElection.Parameters.AddWithValue("@electionId", electionId)
                            Using reader As MySqlDataReader = cmdElection.ExecuteReader()
                                If reader.Read() Then
                                    Label5.Text = "Election: " & reader.GetString("title")
                                    Label6.Text = "Start Date: " & reader.GetDateTime("start_date").ToString("dd/MM/yyyy")
                                    Label7.Text = "End Date: " & reader.GetDateTime("end_date").ToString("dd/MM/yyyy")
                                End If
                            End Using
                        End Using

                        Dim candidateImage1 As String = ""
                        Dim candidateImage2 As String = ""

                        Dim sql As String = "select image_url from candidates where election_id = @electionId"
                        Using cmd As New MySqlCommand(sql, conn)
                            cmd.Parameters.AddWithValue("@electionId", electionId)
                            Using reader As MySqlDataReader = cmd.ExecuteReader()
                                If reader.Read() Then
                                    candidateImage1 = reader.GetString("image_url")
                                End If
                                If reader.Read() Then
                                    candidateImage2 = reader.GetString("image_url")
                                End If
                            End Using
                        End Using

                        ProgressBar1.Maximum = allvotes
                        ProgressBar2.Maximum = allvotes

                        ' Fetch candidate details and vote counts
                        Dim candidateQuery As String = "select c.name, c.party_affiliation, count(v.candidate_id) as votes " &
                            "from candidates c left join votes v on c.candidate_id = v.candidate_id " &
                            "where c.election_id = @electionId " &
                            "group by c.candidate_id"
                        Using cmdCandidate As New MySqlCommand(candidateQuery, conn)
                            cmdCandidate.Parameters.AddWithValue("@electionId", electionId)
                            Using reader As MySqlDataReader = cmdCandidate.ExecuteReader()
                                If reader.Read() Then
                                    PictureBox1.ImageLocation = candidateImage1
                                    Label1.Text = "Name: " & reader.GetString("name")
                                    Label2.Text = "Party: " & reader.GetString("party_affiliation")
                                    Label13.Text = reader.GetString("party_affiliation")
                                    ProgressBar1.Value = Convert.ToInt32(reader("votes"))
                                End If
                                If reader.Read() Then
                                    PictureBox2.ImageLocation = candidateImage2
                                    Label3.Text = "Name: " & reader.GetString("name")
                                    Label4.Text = "Party: " & reader.GetString("party_affiliation")
                                    Label14.Text = reader.GetString("party_affiliation")
                                    ProgressBar2.Value = Convert.ToInt32(reader("votes"))
                                End If
                            End Using
                        End Using

                    End Using
                Catch ex As Exception
                    MessageBox.Show("Error fetching data from the database: " & ex.Message)
                End Try
            Else
                MessageBox.Show("Invalid Election ID. Please enter a valid numeric ID.")
            End If
        Else
            MessageBox.Show("No Election ID provided.")
            Me.Close()
        End If
    End Sub
End Class