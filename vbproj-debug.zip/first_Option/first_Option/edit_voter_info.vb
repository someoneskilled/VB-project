﻿Imports System.Net
Imports MySql.Data.MySqlClient
Public Class edit_voter_info
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim voter_id As Integer = Integer.Parse(TextBox9.Text)
        Dim connStr As String = "server=127.0.0.1;user=root;password=MySQL@6947;database=project"

        Try
            Using conn As New MySqlConnection(connStr)
                conn.Open()

                Dim sql As String = $"select name, address, email, dob from Voters where voter_id = {voter_id}"
                Using cmd As New MySqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@voter_id", voter_id)

                    Using reader As MySqlDataReader = cmd.ExecuteReader()
                        If reader.Read() Then
                            ' Display voter details in textboxes
                            TextBox8.Text = reader.GetString("name")
                            TextBox6.Text = reader.GetString("address")
                            TextBox7.Text = reader.GetString("email")
                            TextBox5.Text = reader.GetDateTime("dob").ToString("yyyy-MM-dd")
                        Else
                            MessageBox.Show("Voter not found.")
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error retrieving voter details: " & ex.Message)
        End Try

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim voter_id As Integer = Integer.Parse(TextBox9.Text)
        Dim new_name As String = TextBox1.Text
        Dim new_email As String = TextBox2.Text
        Dim new_address As String = TextBox3.Text
        Dim new_dob As Date = DateTime.Parse(TextBox4.Text)

        Dim connStr As String = "server=localhost;user=root;password=helloworld;database=project"

        Try
            Using conn As New MySqlConnection(connStr)
                conn.Open()

                Dim sql As String = "update Voters set name = @name, address = @address, email = @email, dob = @dob where voter_id = @voterId"
                Using cmd As New MySqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@name", new_name)
                    cmd.Parameters.AddWithValue("@address", new_address)
                    cmd.Parameters.AddWithValue("@email", new_email)
                    cmd.Parameters.AddWithValue("@dob", new_dob)
                    cmd.Parameters.AddWithValue("@voterId", voter_id)

                    Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                    If rowsAffected > 0 Then
                        MessageBox.Show("Voter information updated successfully.")
                        TextBox1.Text = ""
                        TextBox2.Text = ""
                        TextBox3.Text = ""
                        TextBox4.Text = ""
                        TextBox5.Text = ""
                        TextBox6.Text = ""
                        TextBox7.Text = ""
                        TextBox8.Text = ""
                        TextBox9.Text = ""
                    Else
                        MessageBox.Show("No rows affected. Update failed.")
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error updating voter information: " & ex.Message)
        End Try
    End Sub

    Private Sub edit_voter_info_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class