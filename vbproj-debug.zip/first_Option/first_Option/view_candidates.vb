﻿Imports MySql.Data.MySqlClient

Public Class view_candidates

    Private Sub view_candidates_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Load voter details into the DataGridView when the form is loaded
        LoadCandidateDetails()
    End Sub

    Private Sub LoadCandidateDetails()
        Dim connStr As String = "server=localhost;user=root;password=helloworld;database=project"

        Try
            Using conn As New MySqlConnection(connStr)
                conn.Open()

                Dim sql As String = "SELECT candidate_id, name, party_affiliation, dob, election_id FROM Candidates"
                Using cmd As New MySqlCommand(sql, conn)
                    Using reader As MySqlDataReader = cmd.ExecuteReader()
                        ' Clear the existing rows in the DataGridView
                        DataGridView1.Rows.Clear()

                        ' Read data and add rows to the DataGridView
                        While reader.Read()
                            Dim id As Integer = reader.GetInt32("candidate_id")
                            Dim name As String = reader.GetString("name")
                            Dim party As String = reader.GetString("party_affiliation")
                            Dim dob As Date = reader.GetDateTime("dob")
                            Dim election_id As Integer = reader.GetInt32("election_id")

                            DataGridView1.Rows.Add(id, name, party, dob.ToString("yyyy-MM-dd"), election_id)
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading candidate details: " & ex.Message)
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class
