﻿Public Class Cast_Vote
    Private Sub Cast_Vote_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class