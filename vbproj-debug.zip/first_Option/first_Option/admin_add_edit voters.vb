﻿Public Class admin_add_edit_voters
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        add_voter_info.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        edit_voter_info.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        view_voters.Show()
    End Sub

    Private Sub admin_add_edit_voters_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class