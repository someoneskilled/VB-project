﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class edit_voter_info
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        TextBox1 = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        TextBox2 = New TextBox()
        TextBox3 = New TextBox()
        TextBox4 = New TextBox()
        Button1 = New Button()
        Label7 = New Label()
        Label8 = New Label()
        Label9 = New Label()
        Label10 = New Label()
        TextBox5 = New TextBox()
        TextBox6 = New TextBox()
        TextBox7 = New TextBox()
        TextBox8 = New TextBox()
        TextBox9 = New TextBox()
        Button2 = New Button()
        SuspendLayout()
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(124, 202)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(172, 27)
        TextBox1.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(12, 32)
        Label1.Name = "Label1"
        Label1.Size = New Size(101, 20)
        Label1.TabIndex = 1
        Label1.Text = "Enter Voter ID"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(12, 82)
        Label2.Name = "Label2"
        Label2.Size = New Size(186, 20)
        Label2.TabIndex = 2
        Label2.Text = "Details that can be edited-"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(41, 202)
        Label3.Name = "Label3"
        Label3.Size = New Size(83, 20)
        Label3.TabIndex = 3
        Label3.Text = "New Name"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(41, 333)
        Label4.Name = "Label4"
        Label4.Size = New Size(80, 20)
        Label4.TabIndex = 4
        Label4.Text = "New Email"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(442, 205)
        Label5.Name = "Label5"
        Label5.Size = New Size(96, 20)
        Label5.TabIndex = 5
        Label5.Text = "New Address"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(425, 330)
        Label6.Name = "Label6"
        Label6.Size = New Size(103, 20)
        Label6.TabIndex = 6
        Label6.Text = "Changed DOB"
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(124, 326)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(172, 27)
        TextBox2.TabIndex = 7
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(544, 205)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(172, 27)
        TextBox3.TabIndex = 8
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(544, 327)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(172, 27)
        TextBox4.TabIndex = 9
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(345, 389)
        Button1.Name = "Button1"
        Button1.Size = New Size(94, 29)
        Button1.TabIndex = 11
        Button1.Text = "Insert"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(442, 291)
        Label7.Name = "Label7"
        Label7.Size = New Size(40, 20)
        Label7.TabIndex = 12
        Label7.Text = "DOB"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(44, 291)
        Label8.Name = "Label8"
        Label8.Size = New Size(46, 20)
        Label8.TabIndex = 13
        Label8.Text = "Email"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Location = New Point(442, 167)
        Label9.Name = "Label9"
        Label9.Size = New Size(62, 20)
        Label9.TabIndex = 14
        Label9.Text = "Address"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Location = New Point(44, 164)
        Label10.Name = "Label10"
        Label10.Size = New Size(49, 20)
        Label10.TabIndex = 15
        Label10.Text = "Name"
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(544, 288)
        TextBox5.Name = "TextBox5"
        TextBox5.ReadOnly = True
        TextBox5.Size = New Size(172, 27)
        TextBox5.TabIndex = 16
        ' 
        ' TextBox6
        ' 
        TextBox6.Location = New Point(544, 164)
        TextBox6.Name = "TextBox6"
        TextBox6.ReadOnly = True
        TextBox6.Size = New Size(172, 27)
        TextBox6.TabIndex = 17
        ' 
        ' TextBox7
        ' 
        TextBox7.Location = New Point(124, 288)
        TextBox7.Name = "TextBox7"
        TextBox7.ReadOnly = True
        TextBox7.Size = New Size(172, 27)
        TextBox7.TabIndex = 18
        ' 
        ' TextBox8
        ' 
        TextBox8.Location = New Point(124, 160)
        TextBox8.Name = "TextBox8"
        TextBox8.ReadOnly = True
        TextBox8.Size = New Size(172, 27)
        TextBox8.TabIndex = 19
        ' 
        ' TextBox9
        ' 
        TextBox9.Location = New Point(124, 29)
        TextBox9.Name = "TextBox9"
        TextBox9.Size = New Size(172, 27)
        TextBox9.TabIndex = 20
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(345, 29)
        Button2.Name = "Button2"
        Button2.Size = New Size(94, 27)
        Button2.TabIndex = 21
        Button2.Text = "Search"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' edit_voter_info
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Button2)
        Controls.Add(TextBox9)
        Controls.Add(TextBox8)
        Controls.Add(TextBox7)
        Controls.Add(TextBox6)
        Controls.Add(TextBox5)
        Controls.Add(Label10)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Button1)
        Controls.Add(TextBox4)
        Controls.Add(TextBox3)
        Controls.Add(TextBox2)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(TextBox1)
        Name = "edit_voter_info"
        StartPosition = FormStartPosition.CenterScreen
        Text = "edit_voter_info"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents Button2 As Button
End Class
