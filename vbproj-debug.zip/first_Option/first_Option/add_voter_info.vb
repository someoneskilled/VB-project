﻿Imports System.Security.Cryptography
Imports System.Text
Imports MySql.Data.MySqlClient

Public Class add_voter_info

    Public Function HashPassword(password As String) As String
        Dim sha256 As SHA256 = sha256.Create()
        Dim bytes As Byte() = Encoding.UTF8.GetBytes(password)
        Dim hash As Byte() = sha256.ComputeHash(bytes)
        Dim stringBuilder As StringBuilder = New StringBuilder()

        For i As Integer = 0 To hash.Length - 1
            stringBuilder.Append(hash(i).ToString("x2"))
        Next

        Return stringBuilder.ToString()
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim name As String = TextBox1.Text
        Dim password As String = HashPassword(TextBox2.Text)
        Dim email As String = TextBox3.Text
        Dim address As String = TextBox4.Text
        Dim dob As String = TextBox5.Text

        Dim connStr As String = "server=localhost;user=root;password=helloworld;database=project"

        Try
            Using conn As New MySqlConnection(connStr)
                conn.Open()

                Dim sql As String = "insert into Voters (name, password, email, address, dob) values (@name, @password, @address, @email, @dob)"
                Using cmd As New MySqlCommand(sql, conn)
                    ' Add parameters to the command
                    cmd.Parameters.AddWithValue("@name", name)
                    cmd.Parameters.AddWithValue("@password", password)
                    cmd.Parameters.AddWithValue("@address", address)
                    cmd.Parameters.AddWithValue("@email", email)
                    cmd.Parameters.AddWithValue("@dob", DateTime.Parse(dob))

                    ' Execute the command
                    Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                    If rowsAffected > 0 Then
                        MessageBox.Show("Voter information inserted successfully")
                        TextBox1.Text = ""
                        TextBox2.Text = ""
                        TextBox3.Text = ""
                        TextBox4.Text = ""
                        TextBox5.Text = ""
                    Else
                        MessageBox.Show("No rows affected. Insertion failed.")
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error inserting voter information: " & ex.Message)
        End Try

    End Sub

    Private Sub add_voter_info_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class