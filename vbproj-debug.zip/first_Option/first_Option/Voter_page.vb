﻿Imports MySql.Data.MySqlClient
Public Class Voter_page
    Private voterId As Integer
    Private electionId As Integer
    Private candidateId1 As Integer
    Private candidateId2 As Integer

    Public Sub New(ByVal voterId As Integer)
        InitializeComponent()
        Me.voterId = voterId
    End Sub

    Private Sub Voter_page_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadCandidateDetails()
    End Sub

    Private Sub LoadCandidateDetails()
        Dim connStr As String = "server=localhost;user=root;password=helloworld;database=project"
        Dim electionIdInput As String = InputBox("Enter Election ID:", "ElectionId Input")
        If Integer.TryParse(electionIdInput, electionId) Then
            Try
                Using conn As New MySqlConnection(connStr)
                    conn.Open()

                    Dim sql As String = "SELECT candidate_id, name, party_affiliation, image_url FROM Candidates WHERE election_id = @electionId"
                    Using cmd As New MySqlCommand(sql, conn)
                        cmd.Parameters.AddWithValue("@electionId", electionId)
                        Using reader As MySqlDataReader = cmd.ExecuteReader()
                            Dim count As Integer = 0

                            While reader.Read() AndAlso count < 2
                                Dim candidateID As Integer = reader.GetInt16("candidate_id")
                                Dim candidateName As String = reader.GetString("name")
                                Dim partyAffiliation As String = reader.GetString("party_affiliation")
                                Dim imageUrl As String = reader.GetString("image_url")

                                If count = 0 Then
                                    candidateId1 = candidateID
                                Else
                                    candidateId2 = candidateID
                                End If

                                If count = 0 Then
                                    PictureBox1.ImageLocation = imageUrl
                                    Label1.Text = candidateName
                                    Label2.Text = partyAffiliation
                                Else
                                    PictureBox2.ImageLocation = imageUrl
                                    Label3.Text = candidateName
                                    Label4.Text = partyAffiliation
                                End If

                                count += 1
                            End While
                        End Using
                    End Using
                End Using
            Catch ex As Exception
                MessageBox.Show("Error loading candidate details: " & ex.Message)
            End Try
        Else
            MessageBox.Show("Invalid election ID entered.")
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        UpdateVote(candidateId1)

        'MessageBox.Show("Vote cast for Candidate 1")

        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        UpdateVote(candidateId2)

        'MessageBox.Show("Vote cast for Candidate 2")

        Me.Close()
    End Sub

    Private Sub UpdateVote(candidateId As Integer)
        Dim connStr As String = "server=127.0.0.1;user=root;password=MySQL@6947;database=project"

        Try
            Using conn As New MySqlConnection(connStr)
                conn.Open()

                Dim sql As String = "INSERT INTO votes (voter_id, candidate_id, election_id, vote_datetime) VALUES (@voterId, @candidateId, @electionId, @voteDatetime)"
                Using cmd As New MySqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@voterId", voterId)
                    cmd.Parameters.AddWithValue("@candidateId", candidateId)
                    cmd.Parameters.AddWithValue("@electionId", electionId)
                    cmd.Parameters.AddWithValue("@voteDatetime", DateTime.Now)
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            MessageBox.Show("Vote cast successfully.")

            Me.Close()
        Catch ex As Exception
            MessageBox.Show("Error recording vote: " & ex.Message)
        End Try
    End Sub
End Class
