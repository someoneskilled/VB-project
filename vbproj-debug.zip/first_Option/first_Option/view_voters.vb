﻿Imports MySql.Data.MySqlClient

Public Class view_voters

    Private Sub view_voters_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Load voter details into the DataGridView when the form is loaded
        LoadVoterDetails()
    End Sub

    Private Sub LoadVoterDetails()
        Dim connStr As String = "server=localhost;user=root;password=helloworld;database=project"

        Try
            Using conn As New MySqlConnection(connStr)
                conn.Open()

                Dim sql As String = "select voter_id, name, address, email, dob from Voters"
                Using cmd As New MySqlCommand(sql, conn)
                    Using reader As MySqlDataReader = cmd.ExecuteReader()
                        ' Clear the existing rows in the DataGridView
                        DataGridView1.Rows.Clear()

                        ' Read data and add rows to the DataGridView
                        While reader.Read()
                            Dim voterId As Integer = reader.GetInt32("voter_id")
                            Dim name As String = reader.GetString("name")
                            Dim address As String = reader.GetString("address")
                            Dim email As String = reader.GetString("email")
                            Dim dob As Date = reader.GetDateTime("dob")

                            DataGridView1.Rows.Add(voterId, name, email, address, dob.ToString("yyyy-MM-dd"))
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading voter details: " & ex.Message)
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class
