﻿Public Class elections
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        create_election.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        view_elections.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        finish_election.Show()
    End Sub

    Private Sub elections_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class