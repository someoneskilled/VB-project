﻿Imports MySql.Data.MySqlClient

Public Class create_election

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim title As String = TextBox1.Text
        Dim description As String = TextBox3.Text
        Dim startDate As DateTime = DateTime.Parse(TextBox2.Text)
        Dim endDate As DateTime = DateTime.Parse(TextBox4.Text)

        Dim connStr As String = "server=localhost;user=root;password=helloworld;database=project"

        Try
            Using conn As New MySqlConnection(connStr)
                conn.Open()

                Dim sql As String = "insert into Elections (title, description, start_date, end_date, is_active) VALUES (@title, @description, @startDate, @endDate, 1)"
                Using cmd As New MySqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@title", title)
                    cmd.Parameters.AddWithValue("@description", description)
                    cmd.Parameters.AddWithValue("@startDate", startDate)
                    cmd.Parameters.AddWithValue("@endDate", endDate)

                    Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                    If rowsAffected > 0 Then
                        MessageBox.Show("Election created successfully.")
                        ' Clear the textboxes after successful creation
                        TextBox1.Clear()
                        TextBox2.Clear()
                        TextBox3.Clear()
                        TextBox4.Clear()
                    Else
                        MessageBox.Show("No rows affected. Election creation failed.")
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error creating election: " & ex.Message)
        End Try
    End Sub

    Private Sub create_election_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
