﻿Imports MySql.Data.MySqlClient
Imports System.Security.Cryptography
Imports System.Text

Public Class Voter_Login
    Private voterId As Integer
    Public Function HashPassword(password As String) As String
        Dim sha256 As SHA256 = SHA256.Create()
        Dim bytes As Byte() = Encoding.UTF8.GetBytes(password)
        Dim hash As Byte() = sha256.ComputeHash(bytes)
        Dim stringBuilder As StringBuilder = New StringBuilder()

        For i As Integer = 0 To hash.Length - 1
            stringBuilder.Append(hash(i).ToString("x2"))
        Next

        Return stringBuilder.ToString()
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim connStr As String = "server=localhost;user=root;password=helloworld;database=project"
        Dim voter_id As String = TextBox1.Text
        voterId = voter_id
        Dim hashed_pass As String = HashPassword(TextBox2.Text)
        Dim password As String = ""

        Try
            Using conn As New MySqlConnection(connStr)
                conn.Open()
                Dim sql As String = $"select password from voters where voter_id={voter_id}"
                Using cmd As New MySqlCommand(sql, conn)
                    Using reader As MySqlDataReader = cmd.ExecuteReader()
                        While reader.Read()
                            password = reader.GetString("password")
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error retrieving data: " & ex.Message)
        End Try

        If password = hashed_pass Then
            MessageBox.Show("Login Successful")
            Dim voterPage As New Voter_page(voterId)
            voterPage.Show()
        Else
            MessageBox.Show("Login Unsuccessful")
        End If
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub

    Private Sub Voter_Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class