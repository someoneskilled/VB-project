﻿Public Class Form1
    Private Sub Voter_Click(sender As Object, e As EventArgs) Handles Voter.Click
        ' Open the Voter_Login form
        Dim form As New Voter_Login()
        form.Show()
    End Sub

    Private Sub Admin_Click(sender As Object, e As EventArgs) Handles Admin.Click
        ' Open the Admin_Login form
        Dim form As New Admin_login()
        form.Show()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
