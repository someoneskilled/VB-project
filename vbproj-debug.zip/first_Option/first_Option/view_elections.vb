﻿Imports MySql.Data.MySqlClient

Public Class view_elections
    Private Sub view_elections_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadElectionDetails()
    End Sub

    Private Sub LoadElectionDetails()
        Dim connStr As String = "server=localhost;user=root;password=helloworld;database=project"

        Try
            Using conn As New MySqlConnection(connStr)
                conn.Open()

                Dim sql As String = "select election_id, title, description, start_date, end_date, is_active from Elections"
                Using cmd As New MySqlCommand(sql, conn)
                    Using reader As MySqlDataReader = cmd.ExecuteReader()
                        DataGridView1.Rows.Clear()

                        While reader.Read()
                            Dim id As Integer = reader.GetInt32("election_id")
                            Dim title As String = reader.GetString("title")
                            Dim description As String = reader.GetString("description")
                            Dim startDate As DateTime = reader.GetDateTime("start_date")
                            Dim endDate As DateTime = reader.GetDateTime("end_date")
                            Dim isActive As Boolean = If(reader.GetInt32("is_active") = 1, True, False)

                            DataGridView1.Rows.Add(id, title, description, startDate, endDate, isActive)
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading election details: " & ex.Message)
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class
