﻿Public Class admin_add_edit_cand
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        add_candidates.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        edit_candidates.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        view_candidates.Show()
    End Sub

    Private Sub admin_add_edit_cand_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class