﻿Imports MySql.Data.MySqlClient
Public Class edit_candidates
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim candidate_id As Integer = Integer.Parse(TextBox8.Text)
        Dim connStr As String = "server=127.0.0.1;user=root;password=MySQL@6947;database=project"

        Try
            Using conn As New MySqlConnection(connStr)
                conn.Open()

                Dim sql As String = $"select name, party_affiliation, dob from Candidates where candidate_id={candidate_id}"
                Using cmd As New MySqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@candidate_id", candidate_id)

                    Using reader As MySqlDataReader = cmd.ExecuteReader()
                        If reader.Read() Then
                            TextBox2.Text = reader.GetString("name")
                            TextBox4.Text = reader.GetString("party_affiliation")
                            TextBox6.Text = reader.GetDateTime("dob").ToString("yyyy-MM-dd")
                        Else
                            MessageBox.Show("Candidate not found.")
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error retrieving candidate details: " & ex.Message)
        End Try

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim candidate_id As Integer = Integer.Parse(TextBox8.Text)
        Dim new_name As String = TextBox3.Text
        Dim new_party As String = TextBox5.Text
        Dim new_dob As Date = DateTime.Parse(TextBox7.Text)
        Dim new_image As String = TextBox1.Text

        Dim connStr As String = "server=localhost;user=root;password=helloworld;database=project"

        Try
            Using conn As New MySqlConnection(connStr)
                conn.Open()

                Dim sql As String = "update Candidates set name = @name, party_affiliation = @party_affiliation, dob = @dob, image_url= @imageurl where candidate_id = @candidateId"
                Using cmd As New MySqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@name", new_name)
                    cmd.Parameters.AddWithValue("@party_affiliation", new_party)
                    cmd.Parameters.AddWithValue("@imageurl", new_image)
                    cmd.Parameters.AddWithValue("@dob", new_dob)
                    cmd.Parameters.AddWithValue("@candidateId", candidate_id)

                    Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                    If rowsAffected > 0 Then
                        MessageBox.Show("Candidate information updated successfully.")
                        TextBox1.Text = ""
                        TextBox2.Text = ""
                        TextBox3.Text = ""
                        TextBox4.Text = ""
                        TextBox5.Text = ""
                        TextBox6.Text = ""
                        TextBox7.Text = ""
                        TextBox8.Text = ""

                    Else
                        MessageBox.Show("No rows affected. Update failed.")
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error updating candidate information: " & ex.Message)
        End Try
    End Sub

    Private Sub edit_candidates_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class