﻿Imports MySql.Data.MySqlClient

Public Class add_candidates

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim name As String = TextBox1.Text
        Dim partyaffiliation As String = TextBox2.Text
        Dim dob As Date = DateTime.Parse(TextBox3.Text)
        Dim imagepath As String = TextBox4.Text
        Dim electionid As Integer = Integer.Parse(TextBox5.Text)

        Dim connStr As String = "server=localhost;user=root;password=helloworld;database=project"

        Try
            Using conn As New MySqlConnection(connStr)
                conn.Open()

                Dim sql As String = "INSERT INTO Candidates (name, party_affiliation, dob, image_url, election_id) VALUES (@name, @party_affiliation, @dob, @image_url, @election_id)"
                Using cmd As New MySqlCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@name", name)
                    cmd.Parameters.AddWithValue("@party_affiliation", partyaffiliation)
                    cmd.Parameters.AddWithValue("@dob", dob)
                    cmd.Parameters.AddWithValue("@image_url", imagepath)
                    cmd.Parameters.AddWithValue("@election_id", electionid)

                    Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                    If rowsAffected > 0 Then
                        MessageBox.Show("Candidate added successfully.")
                        ' Clear the textboxes after successful addition
                        TextBox1.Text = ""
                        TextBox2.Text = ""
                        TextBox3.Text = ""
                        TextBox4.Text = ""
                        TextBox5.Text = ""
                    Else
                        MessageBox.Show("No rows affected. Candidate addition failed.")
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error adding candidate: " & ex.Message)
        End Try
    End Sub

    Private Sub add_candidates_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
